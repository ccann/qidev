from distutils.core import setup

setup(
    name='qidev',
    version='1.0',
    packages=['lib', ],
    license='Commercial',
    scripts=['qidev']
)
