from distutils.core import setup

setup(
    name='qidev',
    version='0.1',
    packages=['lib', ],
    license='Commercial',
    scripts=['qidev'],
    package_data={'qidev': ['requirements.txt']}
)
